<?php
class Template_Prove_Choose extends Template {
    protected $template = <<<TEMPLATE_END
<h1>.prove</h1>
Prove to be a real macho.<p/>
There are three ways:<p/>
<a class='method-strength' href="/prove/strength">Strength</a><p/>
<a class='method-stamina' href="/prove/stamina">Stamina</a><p/>
<a class='method-speed' href="/prove/speed">Speed</a><p/>
TEMPLATE_END;
}
