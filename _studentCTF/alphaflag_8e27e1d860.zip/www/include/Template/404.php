<?php
class Template_404 extends Template {
    protected $template = <<<TEMPLATE_END
<h1>.404</h1>
Go away and learn to be a real man.
TEMPLATE_END;
}
