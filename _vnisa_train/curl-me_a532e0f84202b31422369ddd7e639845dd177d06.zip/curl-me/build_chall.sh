#!/bin/bash

docker build -t curl_me .
