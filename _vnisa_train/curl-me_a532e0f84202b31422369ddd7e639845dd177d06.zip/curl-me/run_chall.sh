#!/bin/bash

docker run --rm -ti -p 80:80 --name curl_me_container curl_me
