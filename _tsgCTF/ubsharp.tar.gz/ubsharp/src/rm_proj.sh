#!/bin/sh
rm -rf /tmp/$1
