#!/bin/sh

cp -r ./proj_template /tmp/$1
